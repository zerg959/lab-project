-- Таблица пользователей
CREATE TABLE IF NOT EXISTS "users" (
    "id" INTEGER NOT NULL UNIQUE,
    "name" VARCHAR NOT NULL,
    "email" VARCHAR NOT NULL UNIQUE,
    "role" VARCHAR NOT NULL DEFAULT 'user' CHECK(role IN ('user', 'admin')),
    PRIMARY KEY("id")
);

-- Таблица хранилищ
CREATE TABLE IF NOT EXISTS "storages" (
    "id" INTEGER NOT NULL UNIQUE,
    "user_id" INTEGER NOT NULL,
    "description" VARCHAR DEFAULT 'storage {id}',
    PRIMARY KEY("id"),
    FOREIGN KEY ("user_id") REFERENCES "users"("id")
    ON DELETE CASCADE
);

-- Таблица зон
CREATE TABLE IF NOT EXISTS "zones" (
    "id" INTEGER NOT NULL UNIQUE,
    "storage_id" INTEGER NOT NULL,
    "description" VARCHAR NOT NULL DEFAULT 'zone {id}',
    PRIMARY KEY("id"),
    FOREIGN KEY ("storage_id") REFERENCES "storages"("id")
    ON DELETE CASCADE
);

-- Таблица типов гаджетов
CREATE TABLE IF NOT EXISTS "gadget_types" (
    "id" INTEGER NOT NULL UNIQUE,
    "name" VARCHAR NOT NULL UNIQUE,
    PRIMARY KEY("id")
);

-- Таблица гаджетов
CREATE TABLE IF NOT EXISTS "gadgets" (
    "id" INTEGER NOT NULL UNIQUE,
    "zone_id" INTEGER NOT NULL,
    "description" VARCHAR NOT NULL,
    "type_id" INTEGER NOT NULL,
    "status" VARCHAR DEFAULT 'inactive' CHECK(status IN ('active', 'inactive')),
    PRIMARY KEY("id"),
    FOREIGN KEY ("zone_id") REFERENCES "zones"("id")
    ON DELETE CASCADE,
    FOREIGN KEY ("type_id") REFERENCES "gadget_types"("id")
    ON DELETE CASCADE
);

-- Таблица сенсоров
CREATE TABLE IF NOT EXISTS "sensors" (
    "id" INTEGER NOT NULL UNIQUE,
    "gadget_id" INTEGER NOT NULL,
    "check_period" INTEGER NOT NULL DEFAULT 0,
    "check_time" INTEGER NOT NULL,
    "curr_param" REAL,
    "is_active" INTEGER DEFAULT 0 CHECK(is_active IN (0, 1)),
    "is_outdoor" INTEGER NOT NULL DEFAULT 0 CHECK(is_outdoor IN (0,1)), 
    PRIMARY KEY("id"),
    FOREIGN KEY ("gadget_id") REFERENCES "gadgets"("id")
    ON DELETE CASCADE
);

-- Таблица регуляторов
CREATE TABLE IF NOT EXISTS "regulators" (
    "id" INTEGER NOT NULL UNIQUE,
    "gadget_id" INTEGER NOT NULL,
    "is_active" INTEGER NOT NULL DEFAULT 0 CHECK(is_active IN (0, 1)),
    "on_off_timer" INTEGER,
    "work_time" INTEGER,
    PRIMARY KEY("id"),
    FOREIGN KEY ("gadget_id") REFERENCES "gadgets"("id")
    ON DELETE CASCADE
);

-- Таблица параметров
CREATE TABLE IF NOT EXISTS "params" (
    "id" INTEGER NOT NULL UNIQUE,
    "gadget_id" INTEGER NOT NULL,
    "description" VARCHAR NOT NULL,
    "param_zone_curr" REAL,
    "param_max" REAL,
    "param_min" REAL,
     "outdoor_param" REAL,
    PRIMARY KEY("id"),
    FOREIGN KEY ("gadget_id") REFERENCES "gadgets"("id")
    ON DELETE CASCADE
);