-- Таблица пользователей
CREATE TABLE IF NOT EXISTS "users" (
    "id" SERIAL PRIMARY KEY,
    "name" VARCHAR NOT NULL,
    "email" VARCHAR NOT NULL UNIQUE,
    "role" VARCHAR NOT NULL DEFAULT 'user' CHECK(role IN ('user', 'admin'))
);

-- Таблица хранилищ
CREATE TABLE IF NOT EXISTS "storages" (
    "id" SERIAL PRIMARY KEY,
    "user_id" INTEGER NOT NULL,
    "description" VARCHAR DEFAULT 'storage {id}',
    FOREIGN KEY ("user_id") REFERENCES "users"("id")
    ON DELETE CASCADE
);

-- Таблица зон
CREATE TABLE IF NOT EXISTS "zones" (
    "id" SERIAL PRIMARY KEY,
    "storage_id" INTEGER NOT NULL,
    "description" VARCHAR NOT NULL DEFAULT 'zone {id}',
    FOREIGN KEY ("storage_id") REFERENCES "storages"("id")
    ON DELETE CASCADE
);

-- Таблица типов гаджетов
CREATE TABLE IF NOT EXISTS "gadget_types" (
    "id" SERIAL PRIMARY KEY,
    "name" VARCHAR NOT NULL UNIQUE
);

-- Таблица гаджетов
CREATE TABLE IF NOT EXISTS "gadgets" (
    "id" SERIAL PRIMARY KEY,
    "zone_id" INTEGER NOT NULL,
    "description" VARCHAR NOT NULL,
    "type_id" INTEGER NOT NULL,
    "status" VARCHAR DEFAULT 'inactive' CHECK(status IN ('active', 'inactive')),
    FOREIGN KEY ("zone_id") REFERENCES "zones"("id")
    ON DELETE CASCADE,
    FOREIGN KEY ("type_id") REFERENCES "gadget_types"("id")
    ON DELETE CASCADE
);

-- Таблица сенсоров
CREATE TABLE IF NOT EXISTS "sensors" (
    "id" SERIAL PRIMARY KEY,
    "gadget_id" INTEGER NOT NULL,
    "check_period" INTEGER NOT NULL DEFAULT 0,
    "check_time" TIMESTAMP NOT NULL,
    "curr_param" REAL,
    "is_active" BOOLEAN DEFAULT FALSE,
    "is_outdoor" BOOLEAN NOT NULL DEFAULT FALSE,
    FOREIGN KEY ("gadget_id") REFERENCES "gadgets"("id")
    ON DELETE CASCADE
);

-- Таблица регуляторов
CREATE TABLE IF NOT EXISTS "regulators" (
    "id" SERIAL PRIMARY KEY,
    "gadget_id" INTEGER NOT NULL,
     "is_active" BOOLEAN NOT NULL DEFAULT FALSE,
    "on_off_timer" INTEGER,
    "work_time" INTEGER,
     FOREIGN KEY ("gadget_id") REFERENCES "gadgets"("id")
    ON DELETE CASCADE
);

-- Таблица параметров
CREATE TABLE IF NOT EXISTS "params" (
    "id" SERIAL PRIMARY KEY,
    "gadget_id" INTEGER NOT NULL,
    "description" VARCHAR NOT NULL,
    "param_zone_curr" REAL,
    "param_max" REAL,
    "param_min" REAL,
    "outdoor_param" REAL,
    FOREIGN KEY ("gadget_id") REFERENCES "gadgets"("id")
    ON DELETE CASCADE
);